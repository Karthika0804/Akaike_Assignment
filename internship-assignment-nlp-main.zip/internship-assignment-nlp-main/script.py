## Import all the dependent libraries
import os


def get_mca_questions(context: str):
   mca_questions = [“mca1”,”mca2”,”mca3”....]
   
   return mca_questions  